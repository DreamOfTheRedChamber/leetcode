// Note: This is the most minimal example of a test,
// which is usually good enough as a first test to make sure jest is configured properly

test('making sure jest is configured properly', () => {
  expect(true).toBe(true);
});
